<?php
/**
 * Plugin Name:       TouchData-TM
 * Description:       TouchMessenger基础插件，用于WordPress站点使用TouchMessenger提供的功能服务，已包含催评、测评功能，您只需要在TouchMessenger后台操作功能开关即可使用对用的功能服务
 * Version:           1.0.0
 * Author:            YIGUO-TM Team
 * License:           GPL-2.0+
 * Text Domain:       personalize-login
 */
// 定义插件启动时候调用的方法
register_activation_hook( __FILE__ , 'yg_testing_club');
register_activation_hook( __FILE__ , 'yg_Warranty');
function BaseUrl()
{
    $getBaseUrl = "production";
    switch ($getBaseUrl) {
        case "dev":
            return 'https://fbwh.touchdeals.vip';
            break;
        case "beta":
            return 'https://tmblp.touchdeals.vip';
            break;
        case "production":
            return 'https://www.sharetodays.com';
            break;
    }
}
function yg_test() {
    $response = wp_remote_get( BaseUrl() . '/ygmr/landpage/api/v1/get_website_info?website_type=wordpress&domain_name='.$_SERVER['HTTP_HOST']);
    $body = wp_remote_retrieve_body( $response );
    $body = json_decode( $body, true );
    $uid = $body['uid'];
    $website_id = $body['website_id'];
    $yg_test ='<div id="ygMain"></div><script defer src="'.BaseUrl() .'/shopify/js/common.min.js?uid='.$uid.'&website_id='.$website_id.'" id="ygShopify"></script>
              <script src="' . BaseUrl() . '/shopify/js/test_review.js.min.js?uid='. $uid.'&website_id='.$website_id.'"></script>';
    return $yg_test;
    }
function yg_Warra() {
    $response = wp_remote_get( BaseUrl() .'/ygmr/landpage/api/v1/get_website_info?website_type=wordpress&domain_name='.$_SERVER['HTTP_HOST']);
    $body = wp_remote_retrieve_body( $response );
    $body = json_decode( $body, true );
    $uid = $body['uid'];
    $website_id = $body['website_id'];
    $yg_warranty = "<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css'>
                   <script src='https://cdn.bootcdn.net/ajax/libs/jquery/3.5.1/jquery.js?shop=ysd2020.myshopify.com'></script>
                   <link rel='stylesheet' href='" . BaseUrl() ."/shopify/js/shopify_extensions/style/style.css'><div id='ygMain'></div>
                   <script defer src='" . BaseUrl() ."/shopify/js/shopify_review_guide.js?uid=". $uid."&website_id=".$website_id."  'id='ygShopify'></script>";
    return $yg_warranty;
    }
// Testing Club页面
function  yg_testing_club()
{
    wp_insert_post(
        array( 
            'import_id'      =>  2222,
            'post_content'   =>  yg_test(),
            'post_name'      => 'Testing Club',
            'post_title'     => 'Testing Club',
            'post_status'    => 'publish',
            'post_type'      => 'page',
            'ping_status'    => 'closed',
            'comment_status'  => 'closed',
        )
    );
}
// Warranty页面
function  yg_Warranty() {
    wp_insert_post(
        array(
            'import_id'      =>  3333,
            'post_content'    => yg_Warra(),
            'post_name'      => 'Warranty',
            'post_title'     => 'Warranty',
            'post_status'    => 'publish',
            'post_type'      => 'page',
            'ping_status'    => 'closed',
            'comment_status'  => 'closed',
        )
    );    
}
// 插入JS并且引用JQ, 用date来更新JS
function yg_plug_in() {
    wp_enqueue_script('yg_plugin',plugins_url('./ygplugin.js',__FILE__),array('jquery'),date("h：i：s"));
    global $current_user, $display_name , $user_email;
    get_currentuserinfo();
	 $yg_data_id = array('productid' => get_the_ID(),'account_id' => $current_user->ID, 'BaseUrl' => BaseUrl()); 
	 wp_localize_script('yg_plugin','p_id',$yg_data_id); //php里的参数传到JS
}
// 启动插件时在页脚插入
add_action("wp_footer","yg_plug_in");
// 定义插件停用时候的调用方法
register_deactivation_hook(__FILE__, 'yg_free_end');
function yg_free_end()
{
    wp_delete_post(3333);
    wp_delete_post(2222);
}
?>