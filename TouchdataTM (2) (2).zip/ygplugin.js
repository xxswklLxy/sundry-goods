// 发送GET请求
window.onload = function () {
	console.log(p_id)
    let ygUrl = document.URL//获取当前页面的URL
    let Domain = ygUrl.match(/http[s]?:\/\/(.*?)([:\/]|$)/)//匹配指定URL的domain
    let ygDomain = Domain[1]
    window.ygId = {}
    jQuery.ajax({
        type: 'GET',
        url: `${p_id.BaseUrl}/ygmr/landpage/api/v1/get_website_script?website_type=wordpress&domain_name=${ygDomain}`,
        dataType: 'json',
        async: true,
        success: function (data) {
            ygId = {
                uid: data.uid,
                website_id: data.website_id,
                pid: p_id.productid
            }
            let yg_arr = data.script_list
            yg_url(yg_arr)
            setTimeout(() => {
                yg_urll(yg_arr)
            }, 2000)

        },
        error: function (jqXHR) {
            console.log(jqXHR)
        }
    });
    // 动态插入script
    function yg_url(yg_arr) {
        for (let i = 0; i < yg_arr.length; i++) {
            let yg_head = document.getElementsByTagName('head')[0]
            let yg_script = document.createElement('script')
            yg_script.type = 'text/javascript'
            if (yg_arr[i].search('jquery.min.js') != -1) {
                yg_script.src = yg_arr[i]
                yg_head.appendChild(yg_script)
            }
        }
    }
    // 动态插入script
    function yg_urll(yg_arr) {
        for (let i = 0; i < yg_arr.length; i++) {
            let yg_head = document.getElementsByTagName('head')[0]
            let yg_script = document.createElement('script')
            yg_script.type = 'text/javascript'
            if (yg_arr[i].search('jquery.min.js') == -1) {
                yg_script.src = yg_arr[i]
                yg_head.appendChild(yg_script)
            }
        }
    }
}



